package com.example.demo.model;

import org.springframework.stereotype.Service;

public enum Room {
    Single,
    Double,
    Family_Room
}
