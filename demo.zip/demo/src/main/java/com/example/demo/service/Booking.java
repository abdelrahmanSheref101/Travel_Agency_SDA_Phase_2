package com.example.demo.service;

public interface Booking {
    public String book();
}
