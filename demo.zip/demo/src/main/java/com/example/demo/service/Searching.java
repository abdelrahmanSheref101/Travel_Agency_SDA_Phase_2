package com.example.demo.service;

import com.example.demo.model.Hotel;

import java.util.List;
import java.util.Objects;

public interface Searching {
    public Object search();
}
